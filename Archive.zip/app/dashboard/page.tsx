"use client";

// Lil' Widget — Admin Dashboard (full page)
// - Supabase auth guard
// - Save Widget (name/persona/instructions/website URL)
// - Generate Suggestions (calls /api/crawl-summary)
// - Embed code block
// - Stripe Elements block (SetupIntent) — unchanged from your previous flow
// - Always-on bottom-right PreviewWidget that hits /api/chat with isTest=true
// - Inline tester removed to avoid duplication

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { createClient } from "@/utils/supabase/client";
import { Elements } from "@stripe/react-stripe-js";
import { loadStripe } from "@stripe/stripe-js";
import { PaymentElement, useStripe, useElements } from "@stripe/react-stripe-js";

const stripePromise = loadStripe(process.env.NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY as string);

// --- util: convert plain URLs in text to clickable links ---
function linkify(text: string) {
  if (typeof text !== "string") return "";
  const urlRegex = /(https?:\/\/[^\s]+)/g;
  return text.replace(urlRegex, (url) => `<a href="${url}" target="_blank" rel="noopener noreferrer">${url}</a>`);
}

// --- Always-on bottom-right Preview Widget (Test Mode) ---
function PreviewWidget({ widgetId, persona, instructions }: { widgetId: string; persona: string; instructions: string }) {
  const [open, setOpen] = useState(true);
  const [input, setInput] = useState("");
  const [messages, setMessages] = useState<Array<{ role: "user" | "assistant"; content: string }>>([
    { role: "assistant", content: "Hi! I’m your Lil’ Widget in Test Mode. Tweak persona/instructions above, then try me." },
  ]);

  const send = async () => {
    const text = input.trim();
    if (!text || !widgetId) return;
    const next = [...messages, { role: "user", content: text }];
    setMessages(next);
    setInput("");

    try {
      const res = await fetch("/api/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ message: text, widgetId, persona, instructions, isTest: true }),
      });
      const data = await res.json();
      const reply = data?.reply || "⚠️ No response from assistant.";
      setMessages((m) => [...m, { role: "assistant", content: reply }]);
    } catch (err) {
      console.error("Preview chat error", err);
      setMessages((m) => [...m, { role: "assistant", content: "⚠️ Server error." }]);
    }
  };

  return (
    <div className="fixed bottom-4 right-4 z-[60]">
      {!open && (
        <button onClick={() => setOpen(true)} className="rounded-full shadow-lg px-4 py-3 text-white bg-black" aria-label="Open Lil' Widget">
          Lil’ Widget
        </button>
      )}

      {open && (
        <div className="w-[360px] max-w-[85vw] bg-white border rounded-2xl shadow-2xl overflow-hidden">
          <div className="flex items-center justify-between px-3 py-2 bg-black text-white">
            <div className="font-semibold">Lil’ Widget — Test Mode</div>
            <button onClick={() => setOpen(false)} className="hover:opacity-80" aria-label="Close">
              ✕
            </button>
          </div>
          <div className="px-3 py-2 text-xs text-gray-600 border-b">Chats here are <strong>test</strong> and won’t mix with live site data.</div>
          <div className="h-64 overflow-y-auto p-3 space-y-2">
            {messages.map((m, i) => (
              <div key={i} className={`text-sm ${m.role === "user" ? "text-right" : "text-left"}`}>
                <div
                  className={`inline-block px-3 py-2 rounded-2xl ${m.role === "user" ? "bg-gray-900 text-white" : "bg-gray-100 text-gray-900"}`}
                  dangerouslySetInnerHTML={{ __html: linkify(m.content) }}
                />
              </div>
            ))}
          </div>
          <div className="p-3 border-t">
            <form onSubmit={(e) => { e.preventDefault(); send(); }} className="flex gap-2">
              <input
                value={input}
                onChange={(e) => setInput(e.target.value)}
                placeholder="Type a test message…"
                className="flex-1 border rounded-xl px-3 py-2 text-sm focus:outline-none focus:ring"
              />
              <button type="submit" className="px-4 py-2 rounded-xl text-white bg-black">Send</button>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}

export default function DashboardPage() {
  const router = useRouter();
  const supabase = createClient();

  const [widget, setWidget] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [clientSecret, setClientSecret] = useState("");

  // form fields
  const [widgetName, setWidgetName] = useState("");
  const [persona, setPersona] = useState("");
  const [instructions, setInstructions] = useState("");
  const [websiteUrl, setWebsiteUrl] = useState("");

  // save status
  const [saveStatus, setSaveStatus] = useState<"idle" | "saving" | "saved" | "error">("idle");
  const [suggestLoading, setSuggestLoading] = useState(false);

  // --- Load session + widget row ---
  useEffect(() => {
    const fetchData = async () => {
      const { data: userResp } = await supabase.auth.getUser();
      const user = userResp?.user;
      if (!user) {
        router.push("/register");
        return;
      }

      const { data, error } = await supabase.from("users").select("*").eq("email", user.email).single();
      if (error || !data) {
        console.error("No user row found", error);
        router.push("/register");
        return;
      }

      setWidget(data);
      setWidgetName(data.widget_name || "");
      setPersona(data.persona || "");
      setInstructions(data.instructions || "");
      setWebsiteUrl(data.website_url || "");
      setLoading(false);

      // If you provision SetupIntents server-side, set clientSecret here as needed
      // setClientSecret(data.client_secret || "");
    };

    fetchData();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // --- Save basics ---
  const handleSave = async () => {
    if (!widget?.id) return;
    setSaveStatus("saving");
    const { error } = await supabase
      .from("users")
      .update({ widget_name: widgetName, persona, instructions, website_url: websiteUrl })
      .eq("id", widget.id);

    setSaveStatus(error ? "error" : "saved");
    if (!error) {
      setTimeout(() => setSaveStatus("idle"), 1500);
    }
  };

  // --- Generate suggestions from website ---
  const generateSuggestions = async () => {
    if (!websiteUrl) return;
    setSuggestLoading(true);
    try {
      const res = await fetch("/api/crawl-summary", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ url: websiteUrl }),
      });
      const data = await res.json();

      let personaText = (data.persona || "").trim();
      let instructionText = (data.instructions || "").trim();

      if (!personaText && !instructionText && data.combined) {
        const match = String(data.combined).match(/^(.*?)(?:Instruction Text:|AI Chat Widget Instruction:)(.*)$/s);
        if (match) {
          personaText = match[1].trim();
          instructionText = match[2].trim();
        } else {
          personaText = String(data.combined).trim();
        }
      }

      setPersona(personaText);
      setInstructions(instructionText);

      if (widget?.id) {
        await supabase.from("users").update({ persona: personaText, instructions: instructionText }).eq("id", widget.id);
      }
    } catch (error) {
      console.error("Suggestion generation failed", error);
    } finally {
      setSuggestLoading(false);
    }
  };

  if (loading) return <p className="p-6">Loading your widget...</p>;

  const embedCode = widget?.id
    ? `<iframe src="https://yourdomain.com/widget/${widget.id}" style="width:100%; height:500px; border:none;"></iframe>`
    : "";

  return (
    <div className="p-6 max-w-2xl mx-auto">
      <h1 className="text-2xl font-bold mb-4">👋 Welcome, Friend</h1>

      <div className="space-y-4 mb-6">
        <input
          type="text"
          className="w-full p-2 border rounded"
          placeholder="Widget Name"
          value={widgetName}
          onChange={(e) => setWidgetName(e.target.value)}
        />

        <textarea
          className="w-full p-2 border rounded"
          placeholder="Persona"
          value={persona}
          onChange={(e) => setPersona(e.target.value)}
        />

        <textarea
          className="w-full p-2 border rounded"
          placeholder="Instructions"
          value={instructions}
          onChange={(e) => setInstructions(e.target.value)}
        />

        <div className="flex gap-2">
          <input
            type="text"
            className="w-full p-2 border rounded"
            placeholder="Website URL"
            value={websiteUrl}
            onChange={(e) => setWebsiteUrl(e.target.value)}
          />
          <button onClick={generateSuggestions} className="bg-yellow-500 text-white px-3 py-2 rounded whitespace-nowrap" disabled={suggestLoading}>
            {suggestLoading ? "Loading..." : "Generate Suggestions"}
          </button>
        </div>

        <div className="flex items-center gap-3">
          <button onClick={handleSave} className="bg-blue-600 text-white px-4 py-2 rounded">Save Widget</button>
          {saveStatus === "saved" && <span className="text-green-600">✅ Saved</span>}
          {saveStatus === "error" && <span className="text-red-600">❌ Error saving</span>}
        </div>

        {widget?.id && (
          <div className="mt-4">
            <label className="font-semibold block mb-1">Embed Code</label>
            <textarea className="w-full p-2 border rounded bg-gray-100 text-sm" readOnly value={embedCode} rows={3} />
          </div>
        )}
      </div>

      {/* Stripe Setup (optional) */}
      {!widget?.paid && clientSecret && (
        <Elements options={{ clientSecret }} stripe={stripePromise}>
          <PaymentForm widgetEmail={widget.email} />
        </Elements>
      )}

      {/* Always-on bottom-right preview */}
      {widget?.id && <PreviewWidget widgetId={widget.id} persona={persona} instructions={instructions} />}
    </div>
  );
}

function PaymentForm({ widgetEmail }: { widgetEmail: string }) {
  const stripe = useStripe();
  const elements = useElements();
  const supabase = createClient();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!stripe || !elements) return;

    const result = await stripe.confirmSetup({ elements, confirmParams: {}, redirect: "if_required" });

    if (result.error) {
      console.error(result.error.message);
    } else {
      await supabase.from("users").update({ paid: true }).eq("email", widgetEmail);
      if (typeof window !== "undefined") window.location.reload();
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <PaymentElement />
      <button type="submit" className="bg-green-600 text-white px-4 py-2 rounded w-full">
        Confirm & Save Card
      </button>
    </form>
  );
}
