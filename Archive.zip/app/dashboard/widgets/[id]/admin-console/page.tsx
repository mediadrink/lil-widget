// app/dashboard/widgets/[id]/admin-console/page.tsx
"use client";

import * as React from "react";
import { useRouter } from "next/navigation";

type Widget = {
  id: string;
  title: string;
  url: string;
  persona_text?: string;
  style?: string;
  position?: string;
};

type Rule = {
  id: string;
  text: string;
  version?: string | number | null;
  created_at?: string;
};

function cx(...classes: (string | false | undefined)[]) {
  return classes.filter(Boolean).join(" ");
}

async function fetchJSON<T = any>(input: RequestInfo, init?: RequestInit) {
  const res = await fetch(input, {
    ...init,
    headers: {
      "Content-Type": "application/json",
      ...(init?.headers || {}),
    },
  });
  if (!res.ok) {
    let msg = `HTTP ${res.status}`;
    try {
      const j = await res.json();
      msg = j?.error || msg;
    } catch {}
    throw new Error(msg);
  }
  try {
    return (await res.json()) as T;
  } catch {
    return {} as T; // 204 etc.
  }
}

export default function AdminConsolePage(
  props: { params: Promise<{ id: string }> } // params is a Promise in Next 15 (React 19)
) {
  // ✅ unwrap params with React.use()
  const { id: widgetId } = React.use(props.params);

  const router = useRouter();

  const [loading, setLoading] = React.useState(true);
  const [saving, setSaving] = React.useState(false);
  const [genBusy, setGenBusy] = React.useState(false);
  const [chatBusy, setChatBusy] = React.useState(false);
  const [crawlBusy, setCrawlBusy] = React.useState(false);

  const [widget, setWidget] = React.useState<Widget>({
    id: widgetId,
    title: "",
    url: "",
    persona_text: "",
    style: "style-1",
    position: "bottom-right",
  });

  const [rules, setRules] = React.useState<Rule[]>([]);
  const [newRule, setNewRule] = React.useState("");
  const [editingRuleId, setEditingRuleId] = React.useState<string | null>(null);
  const [editingRuleText, setEditingRuleText] = React.useState("");

  const [suggestions, setSuggestions] = React.useState<string[]>([]);
  const [helperMsg, setHelperMsg] = React.useState("");
  const [helperReply, setHelperReply] = React.useState("");

  const [previewMsg, setPreviewMsg] = React.useState("");
  const [previewReply, setPreviewReply] = React.useState("");

  const [toast, setToast] = React.useState<string | null>(null);

  // 🔧 Embed origin (avoid SSR/CSR mismatch)
  const [embedOrigin, setEmbedOrigin] = React.useState<string>(
    process.env.NEXT_PUBLIC_EMBED_ORIGIN || ""
  );
  React.useEffect(() => {
    if (!embedOrigin && typeof window !== "undefined") {
      setEmbedOrigin(window.location.origin);
    }
  }, [embedOrigin]);

  React.useEffect(() => {
    (async () => {
      try {
        // Load widget
        const w = await fetchJSON<Widget>(`/api/widgets/${widgetId}`, {
          method: "GET",
          cache: "no-store",
        }).catch(() => ({ id: widgetId, title: "", url: "" } as Widget));
        setWidget((prev) => ({
          ...prev,
          title: w?.title ?? "",
          url: w?.url ?? "",
          persona_text: w?.persona_text ?? "",
          style: w?.style ?? "style-1",
          position: w?.position ?? "bottom-right",
        }));

        // Load rules
        const r = await fetchJSON<{ rules: Rule[] }>(
          `/api/widget/${widgetId}/rules`,
          { method: "GET", cache: "no-store" }
        ).catch(() => ({ rules: [] }));
        setRules(r?.rules ?? []);
      } catch (err: any) {
        setToast(`Load failed: ${err.message || String(err)}`);
      } finally {
        setLoading(false);
      }
    })();
  }, [widgetId]);

  function copyEmbed() {
    const origin = embedOrigin || "https://yourdomain.com";
    const snippet = `<iframe src="${origin}/widget/${widgetId}" style="width:100%; height:500px; border:none;"></iframe>`;
    navigator.clipboard.writeText(snippet).then(
      () => setToast("Embed code copied to clipboard."),
      () => setToast("Could not copy embed code.")
    );
  }

  async function saveWidget() {
    setSaving(true);
    try {
      await fetchJSON(`/api/widgets/${widgetId}`, {
        method: "PUT",
        body: JSON.stringify({
          title: widget.title,
          url: widget.url,
          persona_text: widget.persona_text,
          style: widget.style,
          position: widget.position,
        }),
      });
      setToast("Widget saved.");
    } catch (err: any) {
      setToast(`Save failed: ${err.message || String(err)}`);
    } finally {
      setSaving(false);
    }
  }

  async function addRule() {
    const text = newRule.trim();
    if (!text) return;
    const optimistic: Rule = { id: `tmp-${Date.now()}`, text };
    setRules((r) => [optimistic, ...r]);
    setNewRule("");
    try {
      const res = await fetchJSON<{ rule: Rule }>(
        `/api/widget/${widgetId}/rules`,
        {
          method: "POST",
          body: JSON.stringify({ text }),
        }
      );
      setRules((r) => r.map((x) => (x.id === optimistic.id ? res.rule : x)));
      setToast("Rule added.");
    } catch (err: any) {
      setRules((r) => r.filter((x) => x.id !== optimistic.id));
      setToast(`Add rule failed: ${err.message || String(err)}`);
    }
  }

  function startEditRule(rule: Rule) {
    setEditingRuleId(rule.id);
    setEditingRuleText(rule.text);
  }
  function cancelEditRule() {
    setEditingRuleId(null);
    setEditingRuleText("");
  }
  async function saveRuleEdit() {
    if (!editingRuleId) return;
    const text = editingRuleText.trim();
    if (!text) return;
    const original = rules.find((r) => r.id === editingRuleId);
    setRules((r) => r.map((x) => (x.id === editingRuleId ? { ...x, text } : x)));
    try {
      await fetchJSON(
        `/api/widget/${widgetId}/rules/${encodeURIComponent(editingRuleId)}`,
        { method: "PUT", body: JSON.stringify({ text }) }
      );
      setToast("Rule updated.");
      cancelEditRule();
    } catch (err: any) {
      setRules((r) =>
        r.map((x) => (x.id === editingRuleId ? (original as Rule) : x))
      );
      setToast(`Update failed: ${err.message || String(err)}`);
    }
  }

  async function deleteRule(ruleId: string) {
    const original = rules;
    setRules((r) => r.filter((x) => x.id !== ruleId));
    try {
      await fetchJSON(
        `/api/widget/${widgetId}/rules/${encodeURIComponent(ruleId)}`,
        { method: "DELETE" }
      );
      setToast("Rule deleted.");
    } catch (err: any) {
      setRules(original);
      setToast(`Delete failed: ${err.message || String(err)}`);
    }
  }

  async function generateFromSite() {
    if (!widget.url) {
      setToast("Enter your Widget URL first.");
      return;
    }
    setCrawlBusy(true);
    try {
      const res = await fetchJSON<{ summary?: string; persona?: string }>(
        `/api/crawl-summary`,
        { method: "POST", body: JSON.stringify({ url: widget.url }) }
      );
      const persona = res?.persona || res?.summary || "";
      if (persona) {
        setWidget((w) => ({ ...w, persona_text: persona }));
        setToast("Draft persona generated from site.");
      } else {
        setToast("No summary returned.");
      }
    } catch (err: any) {
      setToast(`Generate failed: ${err.message || String(err)}`);
    } finally {
      setCrawlBusy(false);
    }
  }

  async function generateSuggestions() {
    const content =
      helperMsg.trim() ||
      "Suggest 3–5 actionable rules to improve tone, safety, routing, and lead capture.";
    setGenBusy(true);
    setHelperReply("");
    try {
      const res = await fetchJSON<{ reply?: string }>(`/api/admin-assistant`, {
        method: "POST",
        body: JSON.stringify({ message: content, widget_id: widgetId }),
      });
      const reply = res?.reply?.trim() || "";
      setHelperReply(reply);
      const lines =
        reply
          .split("\n")
          .map((l) => l.replace(/^[-*•]\s*/, "").trim())
          .filter(Boolean) || [];
      setSuggestions(lines.slice(0, 10));
      setToast("Suggestions generated.");
    } catch (err: any) {
      setToast(`Admin helper failed: ${err.message || String(err)}`);
    } finally {
      setGenBusy(false);
    }
  }

  async function addSuggestionToRules(text: string) {
    const optimistic: Rule = { id: `tmp-${Date.now()}`, text };
    setRules((r) => [optimistic, ...r]);
    try {
      const res = await fetchJSON<{ rule: Rule }>(
        `/api/widget/${widgetId}/rules`,
        { method: "POST", body: JSON.stringify({ text }) }
      );
      setRules((r) =>
        r.map((x) => (x.id === optimistic.id ? res.rule : x))
      );
      setToast("Suggestion added to rules.");
    } catch (err: any) {
      setRules((r) => r.filter((x) => x.id !== optimistic.id));
      setToast(`Add failed: ${err.message || String(err)}`);
    }
  }

  async function previewChatSend() {
    const msg = previewMsg.trim();
    if (!msg) return;
    setChatBusy(true);
    setPreviewReply("");
    try {
      const res = await fetchJSON<{ reply?: string }>(
        `/api/widget/${widgetId}/chat`,
        { method: "POST", body: JSON.stringify({ message: msg }) }
      );
      setPreviewReply(res?.reply?.trim() || "");
    } catch (err: any) {
      setPreviewReply("");
      setToast(`Chat failed: ${err.message || String(err)}`);
    } finally {
      setChatBusy(false);
    }
  }

  const conversationsHref = `/dashboard/conversations`;
  const settingsHref = `/dashboard/widgets/${widgetId}/admin-console`;

  return (
    <div className="min-h-screen bg-neutral-50 text-neutral-900">
      {/* Top Nav / Tabs */}
      <div className="border-b bg-white">
        <div className="mx-auto max-w-6xl px-4 py-4 flex items-center justify-between">
          <div className="text-lg font-semibold">Lil’ Widget Dashboard</div>
          <div className="flex items-center gap-6">
            <a
              className={cx(
                "text-sm font-medium hover:text-black",
                "border-b-2",
                "border-black"
              )}
              href={settingsHref}
            >
              Widget Settings
            </a>
            <a
              className="text-sm font-medium hover:text-black text-neutral-500"
              href={conversationsHref}
            >
              Conversations
            </a>
          </div>
        </div>
      </div>

      {/* Content */}
      <div className="mx-auto max-w-6xl px-4 py-6">
        {/* Header Section */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-4 mb-6">
          <div className="lg:col-span-2 bg-white rounded-2xl border p-4 shadow-sm">
            <div className="flex flex-col gap-3">
              <div className="text-sm font-semibold">Your Widget Title</div>
              <input
                className="w-full rounded-lg border px-3 py-2 text-sm"
                placeholder="Widget Title"
                value={widget.title}
                onChange={(e) =>
                  setWidget((w) => ({ ...w, title: e.target.value }))
                }
              />
              <div className="text-sm font-semibold">Your Widget URL</div>
              <input
                className="w-full rounded-lg border px-3 py-2 text-sm"
                placeholder="https://example.com"
                value={widget.url}
                onChange={(e) =>
                  setWidget((w) => ({ ...w, url: e.target.value }))
                }
              />
              <div className="flex gap-3">
                <button
                  onClick={saveWidget}
                  disabled={saving}
                  className="rounded-lg bg-black text-white text-sm px-4 py-2 disabled:opacity-50"
                >
                  {saving ? "Saving..." : "Save Widget"}
                </button>
                <button
                  onClick={() => {
                    document
                      .getElementById("preview-chat-section")
                      ?.scrollIntoView({ behavior: "smooth", block: "start" });
                  }}
                  className="rounded-lg border text-sm px-4 py-2 hover:bg-neutral-100"
                >
                  Preview Chat
                </button>
              </div>
            </div>
          </div>

          {/* Style / Position */}
          <div className="bg-white rounded-2xl border p-4 shadow-sm">
            <div className="text-sm font-semibold mb-2">Widget Style</div>
            <select
              className="w-full rounded-lg border px-3 py-2 text-sm mb-3"
              value={widget.style}
              onChange={(e) =>
                setWidget((w) => ({ ...w, style: e.target.value }))
              }
            >
              <option value="style-1">Style 1</option>
              <option value="style-2">Style 2</option>
            </select>

            <div className="text-sm font-semibold mb-2">Widget Position</div>
            <select
              className="w-full rounded-lg border px-3 py-2 text-sm"
              value={widget.position}
              onChange={(e) =>
                setWidget((w) => ({ ...w, position: e.target.value }))
              }
            >
              <option value="bottom-right">Bottom Right</option>
              <option value="bottom-left">Bottom Left</option>
              <option value="top-right">Top Right</option>
              <option value="top-left">Top Left</option>
            </select>
          </div>
        </div>

        {/* Main Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
          {/* LEFT */}
          <div className="lg:col-span-2 flex flex-col gap-4">
            {/* Persona */}
            <section className="bg-white rounded-2xl border p-4 shadow-sm">
              <div className="flex items-center justify-between mb-2">
                <div className="text-sm font-semibold">
                  Your Widget Personality Description
                </div>
                <button
                  onClick={generateFromSite}
                  disabled={crawlBusy}
                  className="text-xs rounded-md border px-3 py-1 hover:bg-neutral-100 disabled:opacity-50"
                >
                  {crawlBusy ? "Generating..." : "Generate from site"}
                </button>
              </div>
              <textarea
                className="w-full min-h-[120px] rounded-lg border px-3 py-2 text-sm"
                placeholder="You can write how you want your widget to act here..."
                value={widget.persona_text}
                onChange={(e) =>
                  setWidget((w) => ({ ...w, persona_text: e.target.value }))
                }
              />
              <p className="mt-2 text-xs text-neutral-500">
                Use words like brief, funny, professional, robotic, informative,
                sales, slang, simple English. Include routing guidance (phone/email).
              </p>
            </section>

            {/* Rules */}
            <section className="bg-white rounded-2xl border p-4 shadow-sm">
              <div className="text-sm font-semibold mb-2">Your Widget Rules</div>

              <div className="flex gap-2 mb-3">
                <input
                  className="flex-1 rounded-lg border px-3 py-2 text-sm"
                  placeholder="Add a new rule…"
                  value={newRule}
                  onChange={(e) => setNewRule(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === "Enter") addRule();
                  }}
                />
                <button
                  onClick={addRule}
                  className="rounded-lg bg-black text-white text-sm px-4 py-2"
                >
                  Add
                </button>
              </div>

              <ul className="divide-y border rounded-lg">
                {rules.length === 0 && (
                  <li className="p-3 text-sm text-neutral-500">No rules yet.</li>
                )}
                {rules.map((r) => (
                  <li key={r.id} className="p-3 flex flex-col gap-2">
                    {editingRuleId === r.id ? (
                      <>
                        <textarea
                          className="w-full rounded-lg border px-3 py-2 text-sm"
                          value={editingRuleText}
                          onChange={(e) => setEditingRuleText(e.target.value)}
                        />
                        <div className="flex gap-2">
                          <button
                            onClick={saveRuleEdit}
                            className="rounded-lg bg-black text-white text-xs px-3 py-1"
                          >
                            Save
                          </button>
                          <button
                            onClick={cancelEditRule}
                            className="rounded-lg border text-xs px-3 py-1 hover:bg-neutral-100"
                          >
                            Cancel
                          </button>
                        </div>
                      </>
                    ) : (
                      <div className="flex flex-col gap-1">
                        <div className="text-sm">{r.text}</div>
                        <div className="text-xs text-neutral-500">
                          <button
                            onClick={() => startEditRule(r)}
                            className="underline mr-3"
                          >
                            edit
                          </button>
                          <button
                            onClick={() => deleteRule(r.id)}
                            className="underline"
                          >
                            delete
                          </button>
                        </div>
                      </div>
                    )}
                  </li>
                ))}
              </ul>
            </section>

            {/* Suggested Rules + Generate Suggestions */}
            <section className="bg-white rounded-2xl border p-4 shadow-sm">
              <div className="flex items-center justify-between mb-2">
                <div className="text-sm font-semibold">Suggested Rules</div>
                <button
                  onClick={generateSuggestions}
                  disabled={genBusy}
                  className="text-xs rounded-md border px-3 py-1 hover:bg-neutral-100 disabled:opacity-50"
                >
                  {genBusy ? "Generating…" : "Generate Suggestions"}
                </button>
              </div>

              <div className="flex gap-2 mb-3">
                <input
                  className="flex-1 rounded-lg border px-3 py-2 text-sm"
                  placeholder="Ask Lil’ Helper (e.g., improve lead capture + bilingual prompts)"
                  value={helperMsg}
                  onChange={(e) => setHelperMsg(e.target.value)}
                />
                <button
                  onClick={generateSuggestions}
                  disabled={genBusy}
                  className="rounded-lg bg-black text-white text-sm px-4 py-2 disabled:opacity-50"
                >
                  Send
                </button>
              </div>

              {helperReply && (
                <div className="mb-3 rounded-lg border bg-neutral-50 p-3 text-sm whitespace-pre-wrap">
                  {helperReply}
                </div>
              )}

              <ul className="divide-y border rounded-lg">
                {suggestions.length === 0 && (
                  <li className="p-3 text-sm text-neutral-500">
                    No suggestions yet.
                  </li>
                )}
                {suggestions.map((s, idx) => (
                  <li key={idx} className="p-3 flex items-start justify-between gap-3">
                    <div className="text-sm">{s}</div>
                    <div>
                      <button
                        onClick={() => addSuggestionToRules(s)}
                        className="rounded-lg border text-xs px-3 py-1 hover:bg-neutral-100"
                      >
                        add
                      </button>
                    </div>
                  </li>
                ))}
              </ul>
            </section>
          </div>

          {/* RIGHT */}
          <div className="flex flex-col gap-4">
            {/* Embed Code */}
            <section className="bg-white rounded-2xl border p-4 shadow-sm">
              <div className="text-sm font-semibold mb-2">
                Embed Code (Paste this in the &lt;head&gt; of your site)
              </div>
              <pre className="rounded-lg border bg-neutral-50 p-3 text-xs overflow-auto">{`<iframe src="${(embedOrigin || "https://yourdomain.com")}/widget/${widgetId}" style="width:100%; height:500px; border:none;"></iframe>`}</pre>
              <button
                onClick={copyEmbed}
                className="mt-2 rounded-lg border text-sm px-3 py-2 hover:bg-neutral-100"
              >
                Copy Embed Code
              </button>
            </section>

            {/* Preview Chat */}
            <section
              id="preview-chat-section"
              className="bg-white rounded-2xl border p-4 shadow-sm"
            >
              <div className="text-sm font-semibold mb-2">Preview Chat</div>
              <div className="flex gap-2 mb-2">
                <input
                  className="flex-1 rounded-lg border px-3 py-2 text-sm"
                  placeholder="Type a message…"
                  value={previewMsg}
                  onChange={(e) => setPreviewMsg(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === "Enter") previewChatSend();
                  }}
                />
                <button
                  onClick={previewChatSend}
                  disabled={chatBusy}
                  className="rounded-lg bg-black text-white text-sm px-4 py-2 disabled:opacity-50"
                >
                  {chatBusy ? "Sending…" : "Send"}
                </button>
              </div>
              {previewReply && (
                <div className="rounded-lg border bg-neutral-50 p-3 text-sm whitespace-pre-wrap">
                  {previewReply}
                </div>
              )}
            </section>

            {/* Lil’ Helper quick box */}
            <section className="bg-white rounded-2xl border p-4 shadow-sm">
              <div className="text-sm font-semibold mb-2">
                Lil’ Helper (Ask me how the widget’s doing)
              </div>
              <div className="flex gap-2">
                <input
                  className="flex-1 rounded-lg border px-3 py-2 text-sm"
                  placeholder="Ask a quick question…"
                  value={helperMsg}
                  onChange={(e) => setHelperMsg(e.target.value)}
                />
                <button
                  onClick={generateSuggestions}
                  disabled={genBusy}
                  className="rounded-lg border text-sm px-3 py-2 hover:bg-neutral-100 disabled:opacity-50"
                >
                  Send
                </button>
              </div>
            </section>
          </div>
        </div>

        {/* Footer actions */}
        <div className="mt-8 flex items-center justify-between">
          <div className="text-xs text-neutral-500">
            Logged in. Changes autosave only when you click{" "}
            <span className="font-medium">Save Widget</span>.
          </div>
          <div className="flex gap-3">
            <a
              href={`/dashboard/conversations`}
              className="rounded-lg border text-sm px-4 py-2 hover:bg-neutral-100"
            >
              Go to Conversations
            </a>
          </div>
        </div>
      </div>

      {/* Toast */}
      {toast && (
        <div className="fixed bottom-4 left-1/2 -translate-x-1/2 rounded-lg bg-black text-white text-sm px-4 py-2 shadow-lg">
          {toast}
          <button
            className="ml-3 underline"
            onClick={() => setToast(null)}
            aria-label="Close"
          >
            close
          </button>
        </div>
      )}

      {/* Loading overlay */}
      {loading && (
        <div className="fixed inset-0 bg-white/70 backdrop-blur-sm grid place-items-center">
          <div className="rounded-2xl border bg-white px-6 py-4 shadow-sm">
            Loading…
          </div>
        </div>
      )}
    </div>
  );
}
