// app/api/admin-assistant/route.ts
// Minimal non-streaming admin helper endpoint.
// Expects: { message: string, widget_id: string }
// Returns: { reply: string }

import { NextRequest, NextResponse } from 'next/server';
import { supabaseServer } from '@/lib/supabaseServer';

export async function POST(req: NextRequest) {
  try {
    const supabase = supabaseServer();

    // Require an authenticated user (RLS-friendly)
    const { data: { user }, error: authErr } = await supabase.auth.getUser();
    if (authErr) {
      // If your supabaseServer doesn't bind cookies from req,
      // ensure it does (createServerClient with cookies).
      console.error(authErr);
    }
    if (!user) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    // Parse body
    const body = await req.json().catch(() => ({} as any));
    const message = String(body?.message ?? '').trim();
    const widget_id = String(body?.widget_id ?? '').trim();

    if (!message || !widget_id) {
      return NextResponse.json(
        { error: 'message and widget_id are required' },
        { status: 400 }
      );
    }

    // Stubbed assistant reply (replace with real LLM later)
    let reply = `You said: "${message}". For now, this is a stubbed reply.`;

    // Demo: emit a suggested rule when 'hours' or 'crawl' appears
    const lower = message.toLowerCase();
    if (lower.includes('hours') || lower.includes('crawl')) {
      const suggestionText =
        'Answer business hours using: Mon–Fri 9–5, Sat 10–2, Sun closed.';

      const text = suggestionText.trim().replace(/\s+/g, ' ');

      const { error: insertErr } = await supabase
        .from('suggested_rules')
        .insert({
          user_id: user.id,      // make sure column is uuid NOT NULL
          widget_id,             // ensure FK/uuid matches your schema
          text,
          confidence: 0.9,
          source_url: 'https://example.com/hours',
          // If column type is text[] this is correct.
          // If it's jsonb, wrap like: JSON.stringify(['hours','info'])
          tags: ['hours', 'info'],
        });

      if (insertErr && insertErr.code !== '23505') {
        // 23505 = unique violation — ignore if you intend idempotency
        console.error('suggested_rules insert error:', insertErr);
      } else if (!insertErr) {
        reply += ' I also proposed a rule based on your request.';
      }
    }

    return NextResponse.json({ reply });
  } catch (err) {
    console.error(err);
    return NextResponse.json(
      { error: (err as Error).message ?? 'Server error' },
      { status: 500 }
    );
  }
}
