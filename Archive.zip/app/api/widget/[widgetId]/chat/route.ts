// app/api/widget/[widgetId]/chat/route.ts
import { NextRequest, NextResponse } from "next/server";
import { supabaseAdmin } from "@/utils/supabase/serverAdmin";

export const dynamic = "force-dynamic";

// TODO: plug in your real model call
async function generateReply(_: { widgetId: string; conversationId: string; message: string }) {
  return "Thanks! (placeholder reply while we wire logging)";
}

export async function POST(
  req: NextRequest,
  { params }: { params: { widgetId: string } }
) {
  try {
    const { widgetId } = params;
    const { conversationId, message, visitorId } = await req.json();

    if (!widgetId || !message) {
      return NextResponse.json({ error: "widgetId and message required" }, { status: 400 });
    }

    // Ensure widget exists (optional tighten with auth)
    const { data: w } = await supabaseAdmin.from("widgets").select("id").eq("id", widgetId).single();
    if (!w) return NextResponse.json({ error: "Widget not found" }, { status: 404 });

    // Create conversation if needed
    let convId = conversationId as string | undefined;
    if (!convId) {
      const { data, error } = await supabaseAdmin
        .from("conversations")
        .insert({ widget_id: widgetId, visitor_id: visitorId ?? null, status: "open" })
        .select("id")
        .single();
      if (error || !data) throw error ?? new Error("Failed to create conversation");
      convId = data.id;
    }

    // Log user message
    const { error: e1 } = await supabaseAdmin.from("messages").insert({
      conversation_id: convId!,
      widget_id: widgetId,
      role: "user",
      content: String(message),
    });
    if (e1) throw e1;

    // Get assistant reply (your model)
    const reply = await generateReply({ widgetId, conversationId: convId!, message: String(message) });

    // Log assistant message
    const { error: e2 } = await supabaseAdmin.from("messages").insert({
      conversation_id: convId!,
      widget_id: widgetId,
      role: "assistant",
      content: reply,
    });
    if (e2) throw e2;

    // Touch conversation
    await supabaseAdmin
      .from("conversations")
      .update({ last_msg_at: new Date().toISOString() })
      .eq("id", convId!);

    return NextResponse.json({ conversationId: convId, reply }, { status: 200 });
  } catch (err: any) {
    console.error(err);
    return NextResponse.json({ error: err?.message ?? "Internal error" }, { status: 500 });
  }
}
