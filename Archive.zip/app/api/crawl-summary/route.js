// File: /app/api/crawl-summary/route.js

import * as cheerio from "cheerio";
import { OpenAI } from "openai";

const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });
const MAX_PAGES = 10;

export async function POST(req) {
  try {
    const { url } = await req.json();
    if (!url) return new Response(JSON.stringify({ error: "Missing URL" }), { status: 400 });

    const res = await fetch(url);
    if (!res.ok) throw new Error(`Failed to fetch: ${res.statusText}`);
    const html = await res.text();
    const $ = cheerio.load(html);

    const text = $("body").text().replace(/\s+/g, " ").trim().slice(0, 5000);

    const prompt = `You are generating content for an AI assistant chatbot.

Based on the following website text, generate:
1. A short persona description (under 50 words) that captures the assistant's tone and specialty.
2. A list of detailed numbered instructions for the assistant to follow, written clearly for use as system instructions.

Do not include headers like "Persona" or "Instructions". Just return the persona paragraph followed by a numbered list.

Website Text:
"""${text}"""`;

    const response = await openai.chat.completions.create({
      model: "gpt-4",
      messages: [{ role: "user", content: prompt }],
    });

    const content = response.choices[0]?.message?.content || "";

    const [personaBlock, ...instructionsBlock] = content.split(/(?:\n)+(?=\d+\.)/); // split at numbered instructions
    const persona = personaBlock.trim();
    const instructions = instructionsBlock.join("\n").trim();

    return new Response(JSON.stringify({ persona, instructions }), { status: 200 });
  } catch (err) {
    console.error("🛑 crawl-summary error:", err);
    return new Response(JSON.stringify({ error: "Failed to generate summary." }), { status: 500 });
  }
}
