// Page: Create Widget (with upsert debug)
"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { createClient } from "@/utils/supabase/client";

export default function CreateWidgetPage() {
  const router = useRouter();
  const supabase = createClient();

  const [widgetName, setWidgetName] = useState("");
  const [persona, setPersona] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  const handleSubmit = async () => {
    if (!widgetName || !persona) {
      setError("Please fill out both fields.");
      return;
    }

    setLoading(true);
    setError("");

    const {
      data: { user },
      error: userError,
    } = await supabase.auth.getUser();

    if (!user || userError) {
      console.error("User not found or error:", userError);
      setError("Authentication error. Please log in again.");
      setLoading(false);
      return;
    }

    console.log("Upserting with:", {
      email: user.email,
      widget_name: widgetName,
      persona,
    });

    const { error } = await supabase.from("users").upsert({
      email: user.email,
      widget_name: widgetName,
      persona: persona,
    });

    if (error) {
      console.error("Insert error:", error);
      setError("Failed to save widget. Try again.");
      setLoading(false);
      return;
    }

    router.push("/dashboard");
  };

  return (
    <div className="p-6 max-w-xl mx-auto">
      <h1 className="text-2xl font-bold mb-4">Create Your Widget</h1>

      <label className="block font-medium mb-1">Widget Name</label>
      <input
        className="w-full p-2 border rounded mb-4"
        value={widgetName}
        onChange={(e) => setWidgetName(e.target.value)}
        placeholder="Example: Portland Dental Widget"
      />

      <label className="block font-medium mb-1">Chatbot Persona / Instructions</label>
      <textarea
        className="w-full p-2 border rounded mb-4 h-32"
        value={persona}
        onChange={(e) => setPersona(e.target.value)}
        placeholder="Tell the bot how to behave (e.g., friendly dental assistant)."
      />

      {error && <p className="text-red-600 mb-4">⚠ {error}</p>}

      <button
        className="bg-black text-white px-4 py-2 rounded w-full"
        onClick={handleSubmit}
        disabled={loading}
      >
        {loading ? "Saving..." : "Save & Continue"}
      </button>
    </div>
  );
}
