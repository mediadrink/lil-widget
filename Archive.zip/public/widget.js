// File: /public/widget.js

(function () {
  const widgetId = document.currentScript.getAttribute("data-id");
  if (!widgetId) return;

  const shadowHost = document.createElement("div");
  shadowHost.style.position = "fixed";
  shadowHost.style.bottom = "20px";
  shadowHost.style.right = "20px";
  shadowHost.style.zIndex = "9999";

  const shadowRoot = shadowHost.attachShadow({ mode: "open" });

  const style = document.createElement("style");
  style.textContent = `
    .widget-container {
      font-family: sans-serif;
      background: white;
      border: 1px solid #ccc;
      border-radius: 8px;
      padding: 1rem;
      width: 300px;
      box-shadow: 0 4px 12px rgba(0,0,0,0.15);
    }
    .widget-container h4 {
      margin: 0 0 0.5rem 0;
    }
    .widget-container input,
    .widget-container textarea {
      width: 100%;
      margin-bottom: 0.5rem;
      padding: 0.5rem;
      border: 1px solid #ccc;
      border-radius: 4px;
    }
    .widget-container button {
      width: 100%;
      padding: 0.5rem;
      background: black;
      color: white;
      border: none;
      border-radius: 4px;
      cursor: pointer;
    }
  `;
  shadowRoot.appendChild(style);

  const container = document.createElement("div");
  container.className = "widget-container";
  container.innerHTML = `
    <h4>Ask Us Anything</h4>
    <textarea placeholder="Type your question..."></textarea>
    <button>Send</button>
    <div class="response" style="margin-top: 0.5rem;"></div>
  `;

  const textarea = container.querySelector("textarea");
  const button = container.querySelector("button");
  const responseDiv = container.querySelector(".response");

  button.onclick = async () => {
    const question = textarea.value.trim();
    if (!question) return;
    responseDiv.textContent = "...";

    const res = await fetch("https://yourdomain.com/api/chat", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        message: question,
        widgetId: widgetId,
      }),
    });

    const data = await res.json();
    responseDiv.textContent = data.reply || "No response.";
  };

  shadowRoot.appendChild(container);
  document.body.appendChild(shadowHost);
})();
